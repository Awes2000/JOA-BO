-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               11.1.2-MariaDB-1:11.1.2+maria~ubu2204 - mariadb.org binary distribution
-- Server OS:                    debian-linux-gnu
-- HeidiSQL Version:             12.5.0.6677
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for BO-JOA
DROP DATABASE IF EXISTS `BO-JOA`;
CREATE DATABASE IF NOT EXISTS `BO-JOA` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `BO-JOA`;

-- Dumping structure for table BO-JOA.SDG
DROP TABLE IF EXISTS `SDG`;
CREATE TABLE IF NOT EXISTS `SDG` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `beschrijving` varchar(10000) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table BO-JOA.SDG: ~17 rows (approximately)
DELETE FROM `SDG`;
INSERT INTO `SDG` (`ID`, `title`, `beschrijving`, `image`, `color`) VALUES
	(1, 'geen armoede', 'Einde aan de armoede gaat over het verminderen van alle vormen van armoede. De SDG-agenda vraagt speciale aandacht voor sociale bescherming, gelijke economische rechten en weerbaarheid van arme en kwetsbare groepen. Omdat armoede in Nederland er anders uit ziet dan armoede in de armste landen van de wereld is dit voor Nederland aangepast. Nederland richt zich op het voorkomen en tegengaan van armoede en problematische schulden, met speciale aandacht voor kinderen die in armoede leven.', 'sdg1_armoede.svg', '#EB3323'),
	(2, 'Geen honger', 'Einde aan honger gaat over het bereiken van voedselzekerheid en het verbeteren van voeding. Het doel is om alle mensen, met name de armen en mensen in kwetsbare situaties, te verzekeren van een gezond en voedzaam dieet.', 'sdg2_honger.svg', '#E4AC3E'),
	(3, 'Goede gezondheid en welzijn', 'Het doel is om een gezond leven te bevorderen voor alle leeftijden en ziekten te bestrijden. Gezondheid gaat verder dan de afwezigheid van ziekte, het omvat lichamelijk, geestelijk en sociaal welzijn.', 'sdg3_gezondheid.svg', '#479d2c'),
	(4, 'Kwaliteitsonderwijs', 'Dit doel gaat over toegang tot kwaliteitsvol en inclusief onderwijs voor iedereen. Het streeft naar gelijke kansen voor leren gedurende het hele leven.', 'sdg4_onderwijs.svg', '#c82c2d'),
	(5, 'Gendergelijkheid', 'Het doel is om genderongelijkheid en discriminatie tegen vrouwen en meisjes te beëindigen. Dit omvat het bevorderen van gelijke rechten, kansen en participatie.', 'sdg5_gendergelijkheid.svg', '#EC5128'),
	(6, 'Schoon water en sanitair', 'Dit doel richt zich op toegang tot schoon water en sanitair voor iedereen. Water is essentieel voor het leven en welzijn.', 'sdg6_water.svg', '#65ABD1'),
	(7, 'Betaalbare en schone energie', 'Het doel is om betaalbare en schone energie beschikbaar te maken voor iedereen. Schone energie draagt bij aan een duurzame toekomst.', 'sdg7_energie.svg', '#ECC05A'),
	(8, 'Eerlijk werk en economische groei', 'Dit doel streeft naar economische groei en werkgelegenheid, met nadruk op fatsoenlijk werk voor iedereen. Het beoogt economische ontwikkeling met sociale rechtvaardigheid.', 'sdg8_werk.svg', '#862A35'),
	(9, 'Industrie, innovatie en infrastructuur', 'Het doel is om duurzame industriële ontwikkeling te bevorderen en innovatie te stimuleren. Dit omvat de opbouw van betrouwbare infrastructuur.', 'sdg9_industrie.svg', '#DF7845'),
	(10, 'Ongelijkheid verminderen', 'Dit doel gaat over het verminderen van ongelijkheid binnen en tussen landen. Het beoogt inclusieve groei en gelijke kansen voor iedereen.', 'sdg10_ongelijkheid.svg', '#D84670'),
	(11, 'Duurzame steden en gemeenschappen', 'Het doel is om steden en nederzettingen inclusief, veilig, veerkrachtig en duurzaam te maken. Het bevordert een betere kwaliteit van leven voor stedelijke bewoners.', 'sdg11_steden.svg', '#E6B355'),
	(12, 'Verantwoorde consumptie en productie', 'Dit doel streeft naar duurzame consumptie- en productiepatronen. Het is gericht op efficiënt gebruik van hulpbronnen en minimalisering van afval.', 'sdg12_consumptie.svg', '#D68E46'),
	(13, 'Klimaatactie', 'Het doel is om maatregelen te nemen om klimaatverandering aan te pakken en de opwarming van de aarde te beperken. Het bevordert acties om de aarde te beschermen.', 'sdg13_klimaat.svg', '#608D42'),
	(14, 'Leven in het water', 'Dit doel gaat over behoud en duurzaam gebruik van de oceanen, zeeën en maritieme hulpbronnen. Het beoogt het leven in water te beschermen en herstellen.', 'sdg14_waterleven.svg', '#4981D2'),
	(15, 'Leven op het land', 'Het doel is om ecosystemen te beschermen, herstellen en duurzaam beheren. Dit omvat behoud van biodiversiteit en bestrijding van woestijnvorming.', 'sdg15_landleven.svg', '#87C05F'),
	(16, 'Vrede, justitie en sterke publieke diensten', 'Dit doel streeft naar vrede, rechtvaardigheid en sterke instellingen. Het omvat het bevorderen van vreedzame en inclusieve samenlevingen.', 'sdg16_vrede.svg', '#305592'),
	(17, 'Partnerschappen om doelstellingen te bereiken', 'Het doel is om wereldwijde partnerschappen te bevorderen om de SDG-doelstellingen te realiseren. Samenwerking tussen landen en sectoren is cruciaal voor succes.', 'sdg17_partnerschappen.svg', '#2F2C8B');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
